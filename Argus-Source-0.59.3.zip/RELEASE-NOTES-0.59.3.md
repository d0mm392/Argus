# Argus 0.59.3 – Einstellungen neu sortiert, Temperaturmessung wieder vollständig

**Neu sortiert**
- Die Einstellungen haben jetzt neun klare Reiter: Allgemein, Seiten und Panel, Kugel, Aussehen, KI und Stimme, Freunde und Medien, Mining, Trading und Smart Home, System.
- Jede Einstellung steht dort, wo man sie sucht. Beispiele: Kugel-Form, Farbe, Neuronen und Last-Anzeige liegen gesammelt unter „Kugel“. Warnschwellen (CPU, GPU, RAM, Laufwerk) stehen unter „System“ statt unter „Mining“. Schnellstart, Fenster-Spiegel und KI-Verlauf stecken nicht mehr im Abschnitt „Notizblock“. Alle Seiten-Schalter (Mining, Gaming, Trading, ioBroker) stehen zusammen unter „Seiten und Panel → Seiten“. Bildrate, Sparoptik, Sparmodus und Kompatibilitätsmodus sind ein Abschnitt „System → Leistung“.
- Zusammengelegt: „Stimme“ und „Argus-Stimmen“, die fünf Trading-Abschnitte zu zwei, „Fehlerberichte“ und „Meine Berichte“, „Grafik“ und „Leistung“.
- Doppeltes entfernt: „Claude-Anzeige“, „Lokal-Anzeige“ und „Strata-Knopf“ gibt es nur noch unter „Kugel → Anzeigen an der Kugel“. In „Seiten und Panel → Fenster im Panel“ schaltet ein Haken das Fenster jetzt wirklich ein (vorher konnte der Haken gesetzt sein, während der Notizblock, das Wetter usw. aus waren).
- Die Suche oben findet weiterhin jede Einstellung über alle Reiter.

**Behoben**
- Freundesliste: Sind Steam oder Discord eingeschaltet, aber nicht eingerichtet, blieb die Liste beim Anklicken einfach weg. Jetzt erscheint ein Hinweis, was fehlt, mit Knopf „Steam einrichten“ bzw. „Discord einrichten“, der direkt an die richtige Stelle der Einstellungen springt.
- Seit 0.58.2 fehlten im Setup der Messtreiber (`PawnIO_setup.exe`) und die Messbibliothek (`LibreHardwareMonitorLib.dll` samt Abhängigkeiten). Die Einrichtung brach mit „Das System kann die angegebene Datei nicht finden“ ab, die Systemwache zeigte „Keine CPU-/GPU-Temperatur“. Die Dateien sind wieder dabei, unverändert aus den offiziellen Quellen (NuGet bzw. signiertes PawnIO-Setup von namazso).
- Fehlen Dateien trotzdem einmal, fragt Argus nicht mehr nach Admin-Rechten, sondern meldet klar, welche Datei fehlt.

**Sicherheit**
- Die Einrichtung prüft vorab die Prüfsummen aller Dateien (`SHA256SUMS.txt`) und die Signatur von namazso am Treiber-Setup. Veränderte Dateien werden nicht verwendet.
- Der Treiber wird beim ersten Start nicht mehr von selbst installiert. Er kommt erst nach einem Klick auf „Einrichten“ (Einstellungen → Temperaturmessung oder Hinweis unter den Messbalken). Wer die Messung schon eingerichtet hatte, merkt davon nichts.
- Der Windows-Bau bricht ab, wenn eine Sensor-Datei fehlt oder nicht zur Prüfliste passt. So kann der Fehler nicht wieder unbemerkt ins Setup rutschen.

**Hinweis**
- Gespeicherte Einstellungen bleiben unverändert, es wurde nur die Anordnung geändert. Beim ersten Öffnen ist der erste Abschnitt jedes Reiters aufgeklappt.
- Veröffentlichung nur im Testkanal `updates`; Stable bleibt unverändert.
