"use strict";
const assert=require('assert/strict'),fs=require('fs'),path=require('path'),{EventEmitter}=require('events');
const {app,ipcMain,safeStorage}=require('electron'),{setup}=require('./renderer-fixture');
async function run(){
 const f=await setup(),{window,profile,evaluate:ev,evaluateWithValue:withValue,wait,screenshot,errors,config}=f;
 const authPath=path.join(profile,'synthetic-discord-auth.bin'),helperPath=path.join(profile,'synthetic-helper.exe');fs.writeFileSync(helperPath,'fixture');
 const children=[];const spawnHelper=()=>{const c=new EventEmitter();c.stdout=new EventEmitter();c.stderr=new EventEmitter();c.stdin={writable:true,write:line=>{if(line.startsWith('revoke'))queueMicrotask(()=>c.event({type:'phase',value:'revoked'}))},end:()=>{c.stdin.writable=false}};c.kill=()=>{};c.event=o=>c.stdout.emit('data',Buffer.from(JSON.stringify(o)+'\n'));children.push(c);return c};
 const service=require('../app/discord-social').create({safeStorage,authPath,helperPath,spawnHelper,platform:'win32',onChange:state=>{if(!window.isDestroyed())window.webContents.send('discord-social',state)}});
 for(const [name,method] of [['state','snapshot'],['connect','connect'],['cancel','cancel'],['disconnect','disconnect']]){ipcMain.removeHandler('discord-social-'+name);ipcMain.handle('discord-social-'+name,event=>{assert.equal(event.sender,window.webContents);return service[method]()})}
 const loaded=new Promise(r=>window.webContents.once('did-finish-load',r));window.reload();await loaded;window.webContents.send('expanded',true);await wait(200);
 await ev("switchPage('Start');market={discord:{servers:[{id:'300000000000000001',server:'Synthetic voice server',online:[{id:'100000000000001',name:'Voice nonfriend',voice:'Room'},{id:'100000000000009',name:'Server only',state:'online'}]}]}};friendsSig='';buildFriends();true");
 const names=()=>ev("[...friendsEl.querySelectorAll('.f b')].map(e=>e.textContent)");
 assert.deepEqual(await names(),['Voice nonfriend']);
 await ev("openSettingsPanel();true");await wait(100);
 await ev("$('setFind').value='Discord';$('setFind').dispatchEvent(new Event('input'));$('dcSocialConnect').click();true");await wait(100);
 assert.equal(service.snapshot().status,'authorizing');assert.equal(await ev("$('dcSocialCancel').hidden"),false);
 await ev("$('dcSocialCancel').click();true");await wait(50);assert.equal(service.snapshot().status,'disconnected');assert(!fs.existsSync(authPath));
 await ev("$('dcSocialConnect').click();true");await wait(50);
 const b64=s=>Buffer.from(s).toString('base64'),c=children.at(-1);
 c.event({type:'tokens',access64:b64('SYNTHETIC_ACCESS'),refresh64:b64('SYNTHETIC_REFRESH'),expiresIn:3600});
 c.event({type:'snapshot',account:{id:'100000000000010',name64:b64('Synthetic account')},friends:[{id:'100000000000001',name64:b64('Voice nonfriend'),status:0},{id:'100000000000002',name64:b64('Online friend'),status:0},{id:'100000000000003',name64:b64('Away friend'),status:3},{id:'100000000000004',name64:b64('Busy friend'),status:4},{id:'100000000000005',name64:b64('Offline friend'),status:1},{id:'100000000000006',name64:b64('Invisible friend'),status:5},{id:'100000000000007',name64:b64('Unknown friend'),status:7}]});await wait(80);
 assert.equal(await ev("$('dcSocialStatus').textContent"),'Verbunden als Synthetic account');assert.equal(await ev("$('setDcOnline').disabled"),false);
 assert(!fs.readFileSync(authPath).includes(Buffer.from('SYNTHETIC_ACCESS')),'real Windows safeStorage hides plaintext');
 await ev("$('setDcOnline').checked=true;$('setDcOnline').dispatchEvent(new Event('change'));true");await wait(70);
 assert.deepEqual(await names(),['Voice nonfriend','Online friend','Away friend','Busy friend']);assert.equal(config.discordAlsoOnline,true);
 await ev("dcMarked=['id:100000000000004'];$('setDcMarked').checked=true;$('setDcMarked').dispatchEvent(new Event('change'));true");await wait(50);assert.deepEqual(await names(),['Voice nonfriend','Busy friend']);assert.equal(config.dcOnlyMarked,true);
 await ev("$('setFind').value='';$('setFind').dispatchEvent(new Event('input'));document.querySelector('#setTabs [data-tab=\"Gaming und Discord\"]').click();const discordHeading=[...document.querySelectorAll('.set-body h4')].find(h=>h.textContent==='Discord');if(discordHeading.getAttribute('aria-expanded')!=='true')discordHeading.click();discordHeading.scrollIntoView({block:'start'});true");await wait(120);
 await screenshot('discord-connected-settings');
 await ev("$('setClose').click();true");await wait(120);assert.equal(await ev("getComputedStyle($('settings')).display"),'none');await screenshot('discord-extra-friends');
 await ev("$('dcSocialDisconnect').click();true");await wait(100);assert.equal(service.snapshot().status,'disconnected');assert(!fs.existsSync(authPath));assert.deepEqual(await names(),['Voice nonfriend']);
 await ev("$('dcSocialConnect').click();true");await wait(40);children.at(-1).event({type:'phase',value:'expired'});await wait(40);assert.match(await ev("$('dcSocialStatus').textContent"),/abgelaufen/);
 await ev("$('dcSocialConnect').click();true");await wait(40);assert.equal(service.snapshot().status,'authorizing');await service.cancel();
 assert.deepEqual(errors,[]);service.close();console.log('PASS Discord Social UI: connect/cancel/reconnect, account status, real DPAPI for artificial tokens, voice unchanged, actual friends only, ID dedupe, marked extras, persisted options, expiry and disconnect cleanup/revocation');app.exit(0);
}
run().catch(e=>{console.error(e.stack);app.exit(1)});setTimeout(()=>app.exit(2),25000).unref();
